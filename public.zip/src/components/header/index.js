import React, { useEffect, useState } from "react";
import { HiOutlineMenuAlt2 } from "react-icons/hi";
import { FaTimes } from "react-icons/fa";
// import Logo from "../../assets/logo.png";
import BSC from "../../assets/BSC.png";
import "./style.css";
import OutsideClickHandler from "react-outside-click-handler";
import Web3 from "web3"
import { toast, ToastContainer } from "react-toastify";
import { useWeb3React } from "@web3-react/core";
import { Injected, WalletConnect } from "../../connector";
import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from "@mui/material";
import { chainIdSelected, logoArray } from "../../config";
import metamask from "../../Img/201-2010951_metamask-ethereum.png";
import walletC from "../../Img/WalletConnect-Logo.png";

const Header = ({ show, setShow }) => {
  const localNet = localStorage.getItem("localNet")
  ? localStorage.getItem("localNet")
  : chainIdSelected ;
  const [open, setOpen] = useState(false);
  const [openA, setOpenA] = useState(false);
  const [network, setNetwork] = useState(localNet);
  const web3 = new Web3(Web3.givenProvider);
  const { account } = useWeb3React()

  useEffect(() => {
    const abc = async () => {

    };
    abc();
  }, [account, network]);

  window.ethereum?.on("accountsChanged", (e, r) => {
    window.location.reload();
  });


  window.ethereum?.on("chainChanged", (e, r) => {
    window.location.reload();
  });
  
 
  if (window.ethereum?.networkVersion !== network) {
    try {
      window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: web3.utils.toHex(network) }],
      });
    } catch (err) {
      // This error code indicates that the chain has not been added to MetaMask
      if (err.code === 4902) {
        // await window.ethereum.request({
        //   method: 'wallet_addEthereumChain',
        //   params: [
        //     {
        //       chainName: 'Polygon Mainnet',
        //       chainId: web3.utils.toHex(chainId),
        //       nativeCurrency: { name: 'MATIC', decimals: 18, symbol: 'MATIC' },
        //       rpcUrls: ['https://polygon-rpc.com/']
        //     }
        //   ]
        // });
        toast("This chain is not configured in your metamask", {
          type: "failure",
          position: toast.POSITION.BOTTOM_CENTER,
          closeOnClick: true,
        });
      }
    }
  }


  return (
    <div className="text-white bg-dark-400 items-center flex justify-between md:justify-end  border-b border-lightDark header">
    <ToastContainer />
      <OutsideClickHandler
        onOutsideClick={() => {
          setShow(false);
        }}
      >
        <button
          className="px-2 text-2xl  md:hidden toggle-bar relative z-50 transition-all duration-300"
          onClick={() => setShow((prev) => !prev)}
        >
          {show ? <FaTimes /> : <HiOutlineMenuAlt2 />}
        </button>
      </OutsideClickHandler>
      <div className="grid grid-flow-col justify-end items-center gap-x-6  px-4 py-4">
        <button 
        onClick={() => {
          setOpenA(true);
        }}
        className="grid grid-flow-col gap-x-2 h-full items-center justify-center font-medium uppercase bg-primary-400 border border-primary-400 bg-opacity-50 p-2 px-4 rounded-md ">
          <img src={BSC} alt="" />
          <p className="hidden sm:block">{window.ethereum?.networkVersion == 97 ? "BSC Testnet" : "Goerli"}</p>
        </button>
        <button 
        onClick={() => {
          setOpen(true);
        }}
        className=" font-medium uppercase bg-primary-400 border border-primary-400 bg-opacity-50 p-2 px-4 rounded-md ">
        {account
                  ? `${account.slice(0, 7)}...${account.slice(-4)}`
                  : "CONNECT"}
        </button>
      </div>
      <ResponsiveDialogWallet
              open={open}
              setOpen={setOpen}
              network={network}
              setNetwork={setNetwork}
            />
             <ResponsiveDialogChain
              open={openA}
              setOpen={setOpenA}
              network={network}
              setNetwork={setNetwork}
            />
    </div>
  );
};

export default Header;



function ResponsiveDialogWallet({ open, setOpen, network, setNetwork }) {
  const { activate, deactivate } = useWeb3React();
  const handleClose = () => {
    setOpen(false);
    activate(WalletConnect);
  };

  const handleClose2 = () => {
    setOpen(false);
    activate(Injected);
  };

  const handleDeactivate = () => {
    setOpen(false);
    deactivate();
  };

  return (

      <div style={{ backgroundColor: "white !important" }}>
        <Dialog

          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >

          <DialogTitle id="alert-dialog-title">
            Please Choose Wallet
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {window.ethereum != undefined ? (
                <div
                style=  {{ cursor: "pointer", border: network==97? "2px solid grey" : "none", padding:"5px", display:"flex" }}

                onClick={handleClose2}
              >
                <span>
                  <img width="50px" src={metamask}></img>
                </span>{" "}
                <span style={{marginLeft:"15px", fontSize:"20px"}}>MetaMask</span>
              </div>
                

              ) : null}

              <br />
              <div
                style=  {{ cursor: "pointer", border: network==97? "2px solid grey" : "none", padding:"5px", display:"flex" }}

                onClick={handleClose}
              >
                <span>
                  <img width="50px" src={walletC}></img>
                </span>{" "}
                <span style={{marginLeft:"15px", fontSize:"20px"}}>Wallet Connectk</span>
              </div>
              
              <br />
              <button
                style={{
                  marginLeft:"10%",
                  cursor: `${network ? "pointer" : null}`,
                  border: "transparent",    
                  borderRadius: "15px",
                  width: "200px",
                  backgroundColor: "rgb(84,84,84)"
                  ,color:"white"
                  ,height:"40px"
                }}
                onClick={handleDeactivate}
              >
                Logout
              </button>
            </DialogContentText>
          </DialogContent>
          <DialogActions></DialogActions>
        </Dialog>
      </div>

  );
}

function ResponsiveDialogChain({ open, setOpen, network, setNetwork }) {
  const { activate, deactivate } = useWeb3React();
  const handleClose = () => {
    setOpen(false);
 
  };

 

  return (

      <div style={{ backgroundColor: "white !important" }}>
        <Dialog

          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            Please Choose Network
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              <div>
                <div

                  style=  {{ cursor: "pointer", border: network==97? "2px solid grey" : "none", padding:"5px", display:"flex" }}
                  onClick={() => {
                    setNetwork("97");
                    setOpen(false)
                    localStorage.setItem("localNet", JSON.stringify(97));
                  }}
                >
                  <span>
                    <img width="50px" src={logoArray["97"]}></img>
                  </span>{" "}
                  <span style={{marginLeft:"15px", fontSize:"25px"}}>BSC Mainnet</span>
                </div>

                <br />
                <div
                  style=  {{ cursor: "pointer", border: network==5? "2px solid grey" : "none", padding:"5px",display:"flex" }}
                  onClick={() => {
                    setNetwork("5");
                    setOpen(false)
                    localStorage.setItem("localNet", JSON.stringify(5));
                  }}
                >
                  <span>
                    <img width="50px" src={logoArray["5"]}></img>
                  </span>{" "}
                  <span style={{marginLeft:"15px", fontSize:"25px"}}>Ethereum Mainnet</span>
                </div>

                {/* <br/>
            <div         style={{ cursor: "pointer" }} onClick={()=>{
              setNetwork("80001")
              localStorage.setItem("localNet",JSON.stringify(80001))
              }}>
            <span><img width="40px" src={logoArray["80001"]}></img></span>
            <span>Polygon</span>
            </div>
             
            <br/>
            <div         style={{ cursor: "pointer" }} onClick={()=>{
              setNetwork("43113")
              localStorage.setItem("localNet",JSON.stringify(43113))
              }}>
            <span><img width="40px" src={logoArray["43113"]}></img></span>
            <span>Avalanche</span>
            </div> */}
              </div>
            </DialogContentText>
          </DialogContent>
       
          <DialogActions></DialogActions>
        </Dialog>
      </div>

  );
}