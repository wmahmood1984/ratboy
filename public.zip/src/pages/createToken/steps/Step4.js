import React from "react";
import { Link } from "react-router-dom";
import ListItem from "../../../components/listItem";
import StepWrap from "../components/StepWrap";

const Step4 = ({ increaseStep, decreaseStep }) => {
  const detailList1 = [
    {
      title: "Total token",
      desc: "16,472  ZETA",
      color: "primary",
    },
    {
      title: "Decimal",
      desc: "18",
    },
    {
      title: "Token symbol",
      desc: "ZETA",
    },
    {
      title: "Token decimals",
      desc: "18",
    },

    {
      title: "Presale rate",
      desc: "100 ZETA",
    },
    {
      title: "Listing rate",
      desc: "zinksale.com/newsales",
    },

    {
      title: "Sale method",
      desc: "Public",
    },
    {
      title: "Softcap",
      desc: "60 BNB",
    },
    {
      title: "Hardcap",
      desc: "100 BNB",
    },
    {
      title: "Minimum buy",
      desc: "0.1 BNB",
    },
    {
      title: "Maximum buy",
      desc: "5 BNB",
    },
    {
      title: "Liquidity",
      desc: "5 BNB",
    },
  ];

  const detailList2 = [
    {
      title: "Token name",
      desc: "Zeta",
    },
    {
      title: "Start time",
      desc: "2022-01-14T00:00 (UTC)",
    },

    {
      title: "End time",
      desc: "2022-01-20T00:00 (UTC)",
    },
    {
      title: "Liquidity lockup time",
      desc: "180 Minutes",
    },
    {
      title: "Website",
      desc: "zinksale.com/newsales",
    },
    {
      title: "Facebook",
      desc: "zinksale.com/facebook",
    },
    {
      title: "Twitter",
      desc: "zinksale.com/twitter",
    },
    {
      title: "Telegram",
      desc: "zinksale.com/telegram",
    },
    {
      title: "Github",
      desc: "zinksale.com/github",
    },
    {
      title: "Instagram",
      desc: "zinksale.com/instagram",
    },
    {
      title: "Reddit",
      desc: "zinksale.com/reddit",
    },
    {
      title: "Using Team Vesting?",
      desc: "No",
    },
  ];
  return (
    <StepWrap>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="grid gap-y-4">
          {detailList1.map((val, i) => (
            <React.Fragment key={i}>
              <ListItem title={val.title} desc={val.desc} color={val.color} />
            </React.Fragment>
          ))}
        </div>
        <div className="grid gap-y-4">
          {detailList2.map((val, i) => (
            <React.Fragment key={i}>
              <ListItem title={val.title} desc={val.desc} color={val.color} />
            </React.Fragment>
          ))}
        </div>
      </div>
      <div className="text-sm mt-10 flex justify-between pb-2 items-center border-b border-lightDark">
        <p className=" ">Description</p>
      </div>
      <p className="text-gray-400 text-xs sm:text-sm mt-2">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto aut at
        repellendus vitae similique tenetur esse excepturi ipsa neque quo
        delectus, aspernatur id dolorem recusandae odio et veritatis animi
        officiis ad illum nam accusantium incidunt placeat eveniet! Enim quas
        quasi mollitia accusantium, nemo quam ullam quaerat officiis. Eius, vero
        accusantium?
      </p>
      <div className="grid grid-flow-col gap-x-8 mt-10 justify-center items-center">
        <button
          onClick={decreaseStep}
          className=" bg-transparent border border-primary-400 py-2 px-8 rounded-md  font-semibold "
        >
          BACK
        </button>
        <Link to="/preview">
          <button
            onClick={increaseStep}
            className=" bg-primary-400 border border-primary-400  py-2 px-8 rounded-md  font-semibold "
          >
            NEXT
          </button>
        </Link>
      </div>
    </StepWrap>
  );
};

export default Step4;
