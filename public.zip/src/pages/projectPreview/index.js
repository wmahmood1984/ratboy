import React from "react";
import { Layout } from "../../components";
import ProjectOverView from "./components/ProjectOverView";
import Swap from "./components/Swap";
import TokenMetrix from "./components/TokenMetrix";
import Ownerzone from "./components/Ownerzone";
import Information from "./components/Information";
import { useLocation } from "react-router-dom";
const ProjectPreview = () => {
  let location = useLocation();
  const { Data } = location.state;
  console.log("data in locaiton",Data)

  return (
    <Layout>
      <main className="px-4 pb-10 pt-28 grid grid-cols-1 gap-y-4">
        <div className=" grid grid-cols-1 md:grid-cols-2 gap-4">
          <ProjectOverView data={Data}/>
          <div className=" flex flex-col">
            <div className="flex-1">
              <Swap data={Data}/>
            </div>
            <div className="mt-6">
              <TokenMetrix data={Data}/>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <Ownerzone data={Data}/>
          <Information data={Data}/>
        </div>
      </main>
    </Layout>
  );
};

export default ProjectPreview;
