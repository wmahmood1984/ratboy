Liquidity 
Liquidity Lock
work on filters
setSocial media for details page
To complete dummy on details page
To set Tokens for Liquidity
To set Buy button
Pie chart left

